#!/bin/bash
grep -e "Sink:" -e "==="
